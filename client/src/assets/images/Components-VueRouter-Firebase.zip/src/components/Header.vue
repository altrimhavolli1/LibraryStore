<template>
<div>
<nav class="navbar navbar-expand-md">
  <a class="navbar-brand" href="#">VueJS - Web</a>
  <button class="navbar-toggler navbar-dark" type="button" data-toggle="collapse" data-target="#main-navigation">
    <span class="navbar-toggler-icon"></span>
  </button>
  <div class="collapse navbar-collapse" id="main-navigation">
    <ul class="navbar-nav">
      <li class="nav-item" >
         <router-link class="nav-link" to="/" >
          <a>Home</a>
        </router-link>
      </li>
      <li class="nav-item">
        <router-link class="nav-link" to="/about" >
          <a>About</a>
        </router-link>
      </li>
      <li class="nav-item">
        <router-link class="nav-link" to="/users-list" >
          <a>Users List</a>
        </router-link>
      </li>

      
      
    </ul>
  </div>
</nav>



</div>

</template>

<script>

export default {
}
</script>
