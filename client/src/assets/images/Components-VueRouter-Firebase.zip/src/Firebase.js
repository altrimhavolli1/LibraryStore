import firebase from 'firebase';

const settings = {timestampsInSnapshots:true};

const config = {
    apiKey:"AIzaSyB_H9Bne1EkfUJWvQrKMAumiP894y7F1ks",
    databaseURL:"https://zhvillimi-web2021-default-rtdb.europe-west1.firebasedatabase.app/",
    projectId:"zhvillimi-web2021"
};
firebase.initializeApp(config);

firebase.firestore().settings(settings);

export default firebase;
